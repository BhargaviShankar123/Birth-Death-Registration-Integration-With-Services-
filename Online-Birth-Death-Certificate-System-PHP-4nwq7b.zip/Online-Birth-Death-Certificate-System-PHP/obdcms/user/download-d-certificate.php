<?php
namespace Dompdf;
require_once '../admin/dompdf/autoload.inc.php';
ob_start();
$con=mysqli_connect("localhost", "root", "", "obdcmsdb");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Death Certificate</title>
<style>
table, td, th {
  border: 1px solid;

}
th, td {
  padding: 15px;
}

table {
  width: 100%;
  border-collapse: collapse;
}
</style>
</head>
<body>
<h2 align="center"> Certificate  of Death</h2>
<hr />

	<?php 

$dcid=intval($_GET['dcid']);
	$ret=mysqli_query($con,"SELECT tbldeathcertificate.*,tbluser.FirstName,tbluser.LastName,tbluser.MobileNumber,tbluser.Address from  tbldeathcertificate join  tbluser on tbldeathcertificate.userId=tbluser.ID where tbldeathcertificate.id='$dcid'");

while ($row=mysqli_fetch_array($ret)) { ?>
<h3> Certificate Number: <?php  echo $row['registrationNumber'];?></h3>
<table  align="center" border="1" width="100%">

 <tr>
    <th scope>Deceased Name</th>
    <td><?php  echo $row['deceasedFullName'];?></td>
    <th scope>Name of Father/Mother/Husband</th>
    <td><?php  echo $row['dnameofFMH'];?></td>
  </tr>
   <tr>
    <th scope>Gender</th>
    <td><?php  echo $row['dgender'];?></td>
    <th scope>Age</th>
    <td><?php  echo $row['dAge'];?></td>
  </tr>
  <tr>
    <th scope>Maritial Status</th>
    <td><?php  echo $row['dMaritialStatus'];?></td>
       <th scope>Date of Death</th>
    <td><?php  echo $row['dateofDeath'];?></td>

  </tr>
   <tr>
<th scope>Time of Death</th>
    <td><?php  echo $row['timeofDeath'];?></td>
    <th scope>Place of Death</th>
    <td><?php  echo $row['placeofDeath'];?></td>

  </tr>
   <tr>
        <th scope>Deceased Permanent Address</th>
    <td><?php  echo $row['dpAddress'];?></td>
    <th scope>Cause of Death</th>
    <td><?php  echo $row['causeofDeath'];?></td>

  </tr>


</table>

<table  align="center" border="1" width="100%" style="margin-top:3%;">
<tr>
	    <th width="150">Certificate Number</th>
    <td><?php  echo $row['registrationNumber'];?></td>
    <th >Apply Date</th>
    <td><?php  echo $row['regDate'];?></td>

  </tr>
   <tr>
    <th width="150">Issued Date</th>
    <td colspan="3"><?php  echo $row['updationDate'];?></td>
  </tr>
</table>

<?php } ?>

<p>THIS IS A COMPUTER GENERATED CERTIFICATE. </p>
</body>
</html>
<?php
$html = ob_get_clean();
$dompdf = new DOMPDF();
$dompdf->setPaper('A4', 'landscape');
$dompdf->load_html($html);
$dompdf->render();
//For view
//$dompdf->stream("",array("Attachment" => false));
// for download
$dompdf->stream("Death-Certificate.pdf");
?>