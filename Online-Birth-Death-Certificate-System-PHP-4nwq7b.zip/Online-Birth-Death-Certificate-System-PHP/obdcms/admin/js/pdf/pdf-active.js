(function ($) {
 "use strict";

		$('a.media').media({width:710, height:950});
		 
 
})(jQuery); 